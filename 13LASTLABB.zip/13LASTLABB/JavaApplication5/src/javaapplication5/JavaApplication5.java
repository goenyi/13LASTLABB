/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication5;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class JavaApplication5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    int digi1;
    int digi2;
    Scanner d1=new Scanner(System.in);
    System.out.println("ingrese cantidad 1");
    digi1=d1.nextInt();
      Scanner d2=new Scanner(System.in);
    System.out.println("ingrese dato 2");
      digi2=d2.nextInt();
    
   if(digi1>digi2){
           System.out.println(digi1"y"digi2);
           else(digi<digi2)
                   System.out.println(digi2"y"diigi1);
           
    }
    
}
